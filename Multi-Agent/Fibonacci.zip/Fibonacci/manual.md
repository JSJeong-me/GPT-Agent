# Fibonacci Generator User Manual

## Introduction

The Fibonacci Generator is a web program developed in Python that generates Fibonacci numbers. This user manual provides detailed instructions on how to install the necessary dependencies and how to use the program.

## Installation

To use the Fibonacci Generator, follow these steps to install the required dependencies:

1. Ensure that you have Python 3.9.7 installed on your system.

2. Open a terminal or command prompt.

3. Navigate to the directory where the program files are located.

4. Run the following command to install the dependencies:

   ```
   pip install -r requirements.txt
   ```

   This will install the required Python packages.

## Usage

Once you have installed the dependencies, you can use the Fibonacci Generator by following these steps:

1. Open a terminal or command prompt.

2. Navigate to the directory where the program files are located.

3. Run the following command to start the program:

   ```
   python main.py
   ```

4. A GUI window titled "Fibonacci Generator" will appear.

5. Enter a number in the input field and click the "Generate" button.

6. The Fibonacci sequence will be displayed below the input field.

   ![Fibonacci Generator GUI](fibonacci_generator_gui.png)

7. You can repeat steps 5 and 6 to generate Fibonacci sequences for different numbers.

8. To exit the program, close the GUI window.

## Troubleshooting

If you encounter any issues while using the Fibonacci Generator, please try the following troubleshooting steps:

1. Ensure that you have installed the dependencies correctly by following the installation instructions.

2. Make sure you are running the program in a compatible Python environment (Python 3.9.7).

3. Check for any error messages displayed in the terminal or command prompt.

   - If you see an "Invalid input" message, make sure you are entering a valid integer number.

   - If you see any other error messages, please refer to the error message for further instructions or contact our support team.

## Conclusion

Congratulations! You have successfully installed and used the Fibonacci Generator. This program allows you to generate Fibonacci sequences easily through a user-friendly GUI. If you have any further questions or need assistance, please don't hesitate to reach out to our support team. Enjoy exploring the world of Fibonacci numbers!