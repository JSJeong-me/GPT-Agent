'''
A web program to generate Fibonacci numbers
'''
import tkinter as tk
class FibonacciGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Fibonacci Generator")
        self.label = tk.Label(root, text="Enter a number:")
        self.label.pack()
        self.entry = tk.Entry(root)
        self.entry.pack()
        self.button = tk.Button(root, text="Generate", command=self.generate_fibonacci)
        self.button.pack()
        self.result_label = tk.Label(root, text="")
        self.result_label.pack()
    def generate_fibonacci(self):
        try:
            num = int(self.entry.get())
            fibonacci_sequence = self.calculate_fibonacci(num)
            self.result_label.config(text=f"Fibonacci sequence: {fibonacci_sequence}")
        except ValueError:
            self.result_label.config(text="Invalid input")
    def calculate_fibonacci(self, num):
        fibonacci_sequence = [0, 1]
        while len(fibonacci_sequence) < num:
            next_num = fibonacci_sequence[-1] + fibonacci_sequence[-2]
            fibonacci_sequence.append(next_num)
        return fibonacci_sequence
if __name__ == "__main__":
    try:
        root = tk.Tk()
        fibonacci_gui = FibonacciGUI(root)
        root.mainloop()
    except tk.TclError as e:
        print(f"Error: {e}")